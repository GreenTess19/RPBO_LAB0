#pragma once

int CompareString(const char* lhs, const char* rhs);