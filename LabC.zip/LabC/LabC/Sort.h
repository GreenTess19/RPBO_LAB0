#pragma once
#include "Structs.h"

void Sort(Person* p, int count, SortTypes type);