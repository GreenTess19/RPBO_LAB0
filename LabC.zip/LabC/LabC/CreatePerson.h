#pragma once
#include "Structs.h"

Person CreatePerson(const char* first_name, const char* second_name, const char* middle_name, unsigned int year);