#pragma once

#include "Structs.h";

Person* GetPersons(int argc, char* argv[], int* count);
